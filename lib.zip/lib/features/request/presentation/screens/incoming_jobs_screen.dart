import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/theme/app_colors.dart';
import '../../controllers/incoming_jobs_controller.dart';
import '../widgets/incoming_job_card.dart';

class IncomingJobsScreen extends StatefulWidget {
  const IncomingJobsScreen({super.key});

  @override
  State<IncomingJobsScreen> createState() => _IncomingJobsScreenState();
}

class _IncomingJobsScreenState extends State<IncomingJobsScreen> {
  final IncomingJobsController _controller = IncomingJobsController();

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onChanged);
    _controller.loadJobs();
  }

  void _onChanged() {
    if (!mounted) return;
    setState(() {});
    final error = _controller.error;
    if (error != null && error.isNotEmpty) {
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(error)));
      _controller.clearError();
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_onChanged);
    _controller.dispose();
    super.dispose();
  }

  Future<void> _refresh() => _controller.loadJobs();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FieldifyColors.surface,
      appBar: AppBar(
        backgroundColor: FieldifyColors.g800,
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Incoming jobs',
          style: GoogleFonts.dmSans(fontWeight: FontWeight.w500),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: _controller.isLoading
            ? const Center(child: CircularProgressIndicator())
            : _controller.jobs.isEmpty
                ? ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(24),
                    children: [
                      const SizedBox(height: 120),
                      Icon(Icons.work_outline,
                          size: 56, color: Colors.black.withAlpha(80)),
                      const SizedBox(height: 16),
                      Text(
                        'No pending jobs right now.',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.dmSans(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: FieldifyColors.ink2,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Pull down to refresh when new requests arrive.',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.dmSans(
                          fontSize: 13,
                          color: FieldifyColors.ink4,
                        ),
                      ),
                    ],
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(20),
                    itemCount: _controller.jobs.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final job = _controller.jobs[index];
                      return IncomingJobCard(
                        job: job,
                        onAccept: () => _controller.acceptJob(job.id),
                        onReject: () => _controller.rejectJobLocally(job.id),
                      );
                    },
                  ),
      ),
    );
  }
}
